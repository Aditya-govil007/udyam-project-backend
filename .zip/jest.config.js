module.exports = {
  testPathIgnorePatterns: ['/node_modules/', '/frontend/'],
  testMatch: ['<rootDir>/backend/**/*.test.js'],
};